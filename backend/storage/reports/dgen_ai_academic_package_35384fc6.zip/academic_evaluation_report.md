# DGen AI — Academic Evaluation & Synthetic Dataset Deliverable Package

**Project Title:** Privacy-Preserving Fraud-Aware Synthetic Banking Transaction Data Generator  
**Degree:** Bachelor of Engineering (Computer Science & Design) Major Project  
**Target Evaluation ID:** `35384fc6-eec6-40a3-884c-75c4314f2259`  
**Overall Quality Score:** **82.84 / 100**  

---

## 📦 Package Purpose & Contents Overview

This downloadable `.zip` package is a **complete, self-contained academic project deliverable** designed for major project submissions, viva presentations, thesis appendix documentation, and reproducible research:

1. `synthetic_banking_dataset.csv` — Full generated synthetic banking dataset ready for ML model training.
2. `quality_scorecard.json` — Comprehensive machine-readable evaluation scorecard for API integration and CI/CD pipelines.
3. `academic_evaluation_report.md` — Complete executive technical report detailing metrics and utility benchmarks.
4. `charts/` — High-resolution statistical plots for embedding into project reports & slides:
   - `charts/correlation_matrix_heatmap.png` — Real vs Synthetic Pearson correlation matrix comparison.
   - `charts/feature_amount_distribution.png` — Kernel Density Estimation (KDE) feature distribution alignment.
   - `charts/fraud_utility_benchmark.png` — Downstream Machine Learning classifier utility comparison (F1-score).

---

## 📊 1. Quality & Privacy Scorecard Summary

- **Overall Score:** `82.84 / 100`
- **Statistical Fidelity Score:** `100.0%`
- **Banking Business Constraint Validity:** `92.56%` (Valid Records: 2314/2500)
- **Synthetic Diversity Score:** `100.0%`
- **Academic Privacy Risk Rating:** `HIGH_RISK` (Mean DCR: 0.0)

---

## 🤖 2. Downstream Fraud Detection ML Utility

- **Model A (Real Only) F1 Score:** `0.0`
- **Model B (Synthetic Only) F1 Score:** `1.0`
- **Model C (Real + Synthetic) F1 Score:** `0.9697`
- **Synthetic Augmentation Gain:** `+0.9697 F1`
- **Utility Verdict:** `BENEFICIAL`

---
*Generated automatically by DGen AI — BE Computer Science & Design Major Project*
